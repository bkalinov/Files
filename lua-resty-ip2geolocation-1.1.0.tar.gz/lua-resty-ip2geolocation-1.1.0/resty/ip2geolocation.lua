local require = require
local cjson = require("cjson")
local http = require("resty.http")
local mlcache = require("resty.mlcache")

local defaults = {
    lru_size        = 1000,
	ttl             = 600, -- 10 minutes
	ttl_jitter      = 0,
	neg_ttl         = 30,  -- 30 seconds
	request_timeout = 150, -- 150 miliseconds
	resurrect_ttl   = 300,  -- 5 minutes
	shm_name        = "ip2geolocation",
	max_retries = 1
}

local cache = nil
local ttl = defaults.ttl
local ttl_jitter = 0
local url = nil
local request_timeout = 0
local max_retries = 0

local _M = {
    _VERSION = "1.0.0"
}

_M.__index = ip2geolocation

function _M.init(opts)
    if cache then
        return "already initialized"
    end

	if opts == nil or opts.url == nil then
		return "no ip2geolocation URL provided"
	end

	ttl = opts.ttl or defaults.ttl
	url = opts.url

	request_timeout = opts.request_timeout or defaults.request_timeout
	
	max_retries = opts.max_retries or defaults.max_retries

	local shm_name = opts.shm_name or defaults.shm_name

    cache, err = mlcache.new("ip2geolocation", shm_name, {
        lru_size      = opts.lru_size or defaults.lru_size,
        ttl           = ttl,
		neg_ttl       = opts.neg_ttl or defaults.neg_ttl,
		resurrect_ttl = opts.resurrect_ttl or defaults.resurrect_ttl
	})
	
	return err
end

local function resolveGeolocationData(addr)
	local httpc = http.new()
	httpc:set_timeout(request_timeout)
	local res, err = httpc:request_uri(url..addr)
	
	local i = 1
	while (not res or err) and i <= max_retries do
      res, err = httpc:request_uri(url..addr)
      i = i + 1
    end
	
	local headers = {}
	if not err then
		local resp_body = cjson.decode(res.body)

		for k, v in pairs(resp_body) do
			if (k == "countryCode" and v ~= cjson.null) then headers["X-IP-Location-Country"] = v   
			elseif (k == "countryId" and v ~= cjson.null) then headers["X-IP-Location-SbCountryId"] = v  
			elseif (k == "subregionName" and v ~= cjson.null)  then headers["X-IP-Location-Subregion"] = v 
			elseif (k == "subregionId" and v ~= cjson.null) then headers["X-IP-Location-SbSubregionId"] = v 
			elseif (k == "cityName" and v ~= cjson.null) then headers["X-IP-Location-City"] = v   
			end
		end	
	else
		-- return nil for both value and error, so that the neg_ttl logic kicks in
	    return nil, nil
	end	
	
	local jittered_ttl = ttl + math.random(0, ttl_jitter)
	
	return headers, nil, jittered_ttl
end

function _M.getGeolocationData(addr)
	if cache then
		return cache:get(addr, nil, resolveGeolocationData, addr)	
	else
		return nil, "no cache available, check for init errors"
	end
end

return _M
